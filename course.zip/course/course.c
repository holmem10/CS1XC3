/**
 * @file course.c
 * @author Megan Holmes 
 * @brief Course library for managing courses, including definitions of Course functions
 * @version 0.1
 * @date 2022-04-12
 * 
 * @copyright Copyright (c) 2022
 * 
 */
#include "course.h"
#include <stdlib.h>
#include <stdio.h>
 /**
  * Uses dynamic memory allocation to enroll a 
  * new student into a specific course. First creates a dynamic array if 
  * none has been created so far, else will resize the array.
  * 
  * @param course 
  * @param student 
  */
void enroll_student(Course *course, Student *student)
{
  course->total_students++;
  if (course->total_students == 1) 
  {
    course->students = calloc(1, sizeof(Student)); //create new dynamically allocated array if this is the first student
  }
  else 
  {
    course->students = 
      realloc(course->students, course->total_students * sizeof(Student)); //resize the array for every new student added after the first student
  }
  course->students[course->total_students - 1] = *student;//add student
}
/**
 * Prints a course and all it's information including
 * course name, code, total number of students, and each student.
 * 
 * @param course 
 */
void print_course(Course* course)
{
  printf("Name: %s\n", course->name);
  printf("Code: %s\n", course->code);
  printf("Total students: %d\n\n", course->total_students);
  printf("****************************************\n\n");
  for (int i = 0; i < course->total_students; i++) //for loop to print each student
    print_student(&course->students[i]);
}
/**
 * Returns the top student in a course by grade using compare sort. 
 * 
 * @param course 
 * @return Student* 
 */
Student* top_student(Course* course)
{
  if (course->total_students == 0) return NULL; //no top student if no students are enrolled
 
  double student_average = 0;
  double max_average = average(&course->students[0]);
  Student *student = &course->students[0];
 
  for (int i = 1; i < course->total_students; i++)
  {
    student_average = average(&course->students[i]);
    if (student_average > max_average) //compare student with max average
    {
      max_average = student_average;//if student has greater average, save as max
      student = &course->students[i];//go to next student
    }   
  }

  return student;
}

/**
 * returns an array of type Student including all students
 * in a specified course that are passing the course. 
 * Counts number of passing students. Creates dynamic array
 * with size of number of passing students and fills it with passing
 * students.
 * 
 * @param course 
 * @param total_passing 
 * @return Student* 
 */
Student *passing(Course* course, int *total_passing)
{
  int count = 0;
  Student *passing = NULL;
  
  for (int i = 0; i < course->total_students; i++) 
    if (average(&course->students[i]) >= 50) count++;//count each student in a course that has a passing average
  
  passing = calloc(count, sizeof(Student)); //create dynamically allocated array of size of number of passing students

  int j = 0;
  for (int i = 0; i < course->total_students; i++) //loop through each student in course
  {
    if (average(&course->students[i]) >= 50)
    {
      passing[j] = course->students[i];//insert passing students into array
      j++; //move up a place in array index only if student has been added
    }
  }

  *total_passing = count; //assign calculated number of passing students to pointer given in parameter

  return passing;
}