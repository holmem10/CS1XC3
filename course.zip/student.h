 /**
  * @file student.h
  * @author Megan Holmes
  * @date 03/12/22
  * @brief Student library for managing students, including 
  *        student type definition and student functions.
  * 
  */

 /**
  * Student type stores a student with fields first_name, 
  * last_name, id, *grades, and num_grades.
  * 
  */
typedef struct _student 
{ 
  char first_name[50]; /**< the student's name */
  char last_name[50];/**< the student's last name */
  char id[11];/**< the student's id */
  double *grades;/** the student's grades */
  int num_grades; /** the number of student's grades */
} Student;

void add_grade(Student *student, double grade);
double average(Student *student);
void print_student(Student *student);
Student* generate_random_student(int grades); 
